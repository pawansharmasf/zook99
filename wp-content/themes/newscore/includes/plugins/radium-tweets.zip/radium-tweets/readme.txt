Display tweets in Wordpress


Changelog

1.0.9

* Switched plugin to use transient api for caching
* Added button to clear cache to widget
* Added translation strings for theme options
* Fixed broken page on tweets error

1.0

Initial Release